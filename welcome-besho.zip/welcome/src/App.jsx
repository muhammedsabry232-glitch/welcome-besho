import React, { useState, useEffect, useRef, useCallback } from 'react';
import {
  Sparkles, Upload, Download, Play, Pause, RotateCcw, Layers,
  Scissors, Eye, EyeOff, Sliders, CheckCircle2, Cpu, FileCode,
  ZoomIn, ZoomOut, Crown, Undo2, Eraser, Paintbrush, Save,
  FolderOpen, HardDrive, Smartphone, Wifi, WifiOff, Trash2
} from 'lucide-react';

const MADEIRA_PALETTE = [
  { code: '#1800', name: 'أسود فاحم (Jet Black)', hex: '#141416', keywords: ['اسود', 'أسود', 'سوداء', 'كحل', 'black'] },
  { code: '#1801', name: 'أبيض ثلجي (Snow White)', hex: '#F7F7F2', keywords: ['ابيض', 'أبيض', 'بيضاء', 'ثلجي', 'white'] },
  { code: '#1838', name: 'أحمر قرمزي (Crimson Red)', hex: '#C81018', keywords: ['احمر', 'أحمر', 'حمراء', 'قرمزي', 'نبيتي', 'red'] },
  { code: '#1724', name: 'ذهبي ملكي (Royal Gold)', hex: '#EAB308', keywords: ['ذهبي', 'دهبي', 'دهب', 'اصفر', 'أصفر', 'gold', 'yellow'] },
  { code: '#1842', name: 'أزرق بورش (Porsche Blue)', hex: '#0D47A1', keywords: ['ازرق', 'أزرق', 'زرقاء', 'كحلي', 'لبني', 'سماوي', 'blue'] },
  { code: '#1951', name: 'أخضر زمردي (Emerald Green)', hex: '#10B981', keywords: ['اخضر', 'أخضر', 'خضراء', 'زيتي', 'green'] },
  { code: '#1818', name: 'رمادي دخاني (Smoke Grey)', hex: '#94A3B8', keywords: ['رمادي', 'رصاصي', 'فضي', 'سيلفر', 'grey', 'gray', 'silver'] },
  { code: '#1972', name: 'برتقالي ناري (Amber Orange)', hex: '#F97316', keywords: ['برتقالي', 'اورنج', 'بني', 'جملي', 'orange', 'brown'] },
];

const MASK_W = 480;
const MASK_H = 260;

// تحويل الإحداثيات إلى باينري Tajima .DST حقيقي (512-byte Header + 3-byte Ternary Packets)
function encodeDSTPacket(dx, dy, flag = 'normal') {
  dx = Math.max(-121, Math.min(121, Math.round(dx)));
  dy = Math.max(-121, Math.min(121, Math.round(dy)));
  const weights = [81, 27, 9, 3, 1];
  const toBTer = (val) => {
    let v = val;
    return weights.map((w) => {
      let d = 0;
      if (v > (w - 1) / 2) d = 1;
      else if (v < -(w - 1) / 2) d = -1;
      v -= d * w;
      return d;
    });
  };
  const [x81, x27, x9, x3, x1] = toBTer(dx);
  const [y81, y27, y9, y3, y1] = toBTer(dy);
  let b0 = 0, b1 = 0, b2 = 0b00000011;
  if (x1 === 1) b0 |= 1; else if (x1 === -1) b0 |= 2;
  if (x9 === 1) b0 |= 4; else if (x9 === -1) b0 |= 8;
  if (x3 === 1) b1 |= 1; else if (x3 === -1) b1 |= 2;
  if (x27 === 1) b1 |= 4; else if (x27 === -1) b1 |= 8;
  if (x81 === 1) b2 |= 4; else if (x81 === -1) b2 |= 8;

  if (y1 === 1) b0 |= 128; else if (y1 === -1) b0 |= 64;
  if (y9 === 1) b0 |= 32; else if (y9 === -1) b0 |= 16;
  if (y3 === 1) b1 |= 128; else if (y3 === -1) b1 |= 64;
  if (y27 === 1) b1 |= 32; else if (y27 === -1) b1 |= 16;
  if (y81 === 1) b2 |= 32; else if (y81 === -1) b2 |= 16;

  if (flag === 'jump') b2 |= 0b10000000;
  else if (flag === 'color') b2 |= 0b11000000;
  else if (flag === 'end') return [0x00, 0x00, 0xf3];
  return [b0, b1, b2];
}

function generateBinaryDST(label, needlesList, stitchesByNeedle) {
  const bytes = [];
  let curX = 0, curY = 0, minX = 0, maxX = 0, minY = 0, maxY = 0, totalRecs = 0;
  const activeNeedles = needlesList.filter((n) => n.visible && (stitchesByNeedle[n.id]?.length > 0));

  activeNeedles.forEach((n, cIdx) => {
    if (cIdx > 0) {
      bytes.push(...encodeDSTPacket(0, 0, 'color'));
      totalRecs++;
    }
    const pts = stitchesByNeedle[n.id] || [];
    pts.forEach((pt, pIdx) => {
      const tx = Math.round(pt.x * 10);
      const ty = Math.round(-pt.y * 10);
      let dx = tx - curX;
      let dy = ty - curY;
      const isJump = pIdx === 0 || pt.jump;
      while (Math.abs(dx) > 121 || Math.abs(dy) > 121) {
        const sx = Math.max(-121, Math.min(121, dx));
        const sy = Math.max(-121, Math.min(121, dy));
        bytes.push(...encodeDSTPacket(sx, sy, 'jump'));
        totalRecs++;
        curX += sx; curY += sy;
        dx = tx - curX; dy = ty - curY;
      }
      bytes.push(...encodeDSTPacket(dx, dy, isJump ? 'jump' : 'normal'));
      totalRecs++;
      curX += dx; curY += dy;
      minX = Math.min(minX, curX); maxX = Math.max(maxX, curX);
      minY = Math.min(minY, curY); maxY = Math.max(maxY, curY);
    });
  });

  bytes.push(...encodeDSTPacket(0, 0, 'end'));
  totalRecs++;

  const headerStr =
    `LA:${label.slice(0, 16).padEnd(16, ' ')}\r` +
    `ST:${String(totalRecs).padStart(7, ' ')}\r` +
    `CO:${String(Math.max(0, activeNeedles.length - 1)).padStart(3, ' ')}\r` +
    `+X:${String(Math.abs(maxX)).padStart(5, ' ')}\r` +
    `-X:${String(Math.abs(minX)).padStart(5, ' ')}\r` +
    `+Y:${String(Math.abs(maxY)).padStart(5, ' ')}\r` +
    `-Y:${String(Math.abs(minY)).padStart(5, ' ')}\r` +
    `AX:+    0\rAY:+    0\rMX:+    0\rMY:+    0\rPD:******\r`;

  const header = new Uint8Array(512).fill(0x20);
  for (let i = 0; i < headerStr.length; i++) header[i] = headerStr.charCodeAt(i);
  header[headerStr.length] = 0x1a;

  const out = new Uint8Array(512 + bytes.length);
  out.set(header, 0);
  out.set(bytes, 512);
  return new Blob([out], { type: 'application/octet-stream' });
}

export default function App() {
  const [designMode, setDesignMode] = useState('calligraphy'); // 'calligraphy' | 'bitmap'
  const [calligraphyText, setCalligraphyText] = useState('محمد');
  const [bottomCaption, setBottomCaption] = useState('');
  const [hasCrown, setHasCrown] = useState(false);
  const [widthMm, setWidthMm] = useState(100);
  const [heightMm, setHeightMm] = useState(42);
  const [fabricBg, setFabricBg] = useState('#0f172a');
  const [viewMode, setViewMode] = useState('trueview'); // 'trueview' | 'vectors' | 'films'
  const [mouseTool, setMouseTool] = useState('pan'); // 'pan' | 'eraser' | 'recolor'
  const [targetRecolorNeedle, setTargetRecolorNeedle] = useState(3);
  const [zoom, setZoom] = useState(1);

  const [needles, setNeedles] = useState([
    { id: 1, name: 'الإبرة #1 (اليمين والأطراف)', color: '#141416', code: '#1800', type: 'Tatami', density: 0.38, angle: 72, pullComp: 0.25, satinWidth: 2.2, visible: true },
    { id: 2, name: 'الإبرة #2 (القلب والمنتصف)', color: '#F7F7F2', code: '#1801', type: 'Tatami', density: 0.36, angle: 72, pullComp: 0.25, satinWidth: 2.2, visible: true },
    { id: 3, name: 'الإبرة #3 (برواز الساتان)', color: '#C81018', code: '#1838', type: 'Satin', density: 0.34, angle: 45, pullComp: 0.30, satinWidth: 2.4, visible: true },
  ]);

  const layerMasksRef = useRef({
    1: new Uint8Array(MASK_W * MASK_H),
    2: new Uint8Array(MASK_W * MASK_H),
    3: new Uint8Array(MASK_W * MASK_H),
  });

  const [maskVersion, setMaskVersion] = useState(0);
  const [stitchesByNeedle, setStitchesByNeedle] = useState({ 1: [], 2: [], 3: [] });
  const [totalStitches, setTotalStitches] = useState(0);
  const [jumpCount, setJumpCount] = useState(0);

  const [isPlaying, setIsPlaying] = useState(false);
  const [playProgress, setPlayProgress] = useState(1);
  const [spm, setSpm] = useState(750);

  const [chatInput, setChatInput] = useState('');
  const [chatHistory, setChatHistory] = useState([
    {
      role: 'ai',
      text: 'أهلاً بك يا هندسة في Wilcom AI Studio Pro (نسخة الـ PWA الاحترافية)! اكتب أي تعديل بالعامية المصرية أو ارفع أي صورة أو لوجو وهنفذه فوراً على الغرز.',
      diffs: ['جاهز للعمل Offline وحفظ ملفات .DST مباشرة للفلاشة'],
    },
  ]);
  const [lastDiffBanner, setLastDiffBanner] = useState('جاهز للتشغيل المباشر');
  const [undoStack, setUndoStack] = useState([]);

  // PWA & Projects state
  const [isOnline, setIsOnline] = useState(typeof navigator !== 'undefined' ? navigator.onLine : true);
  const [deferredPrompt, setDeferredPrompt] = useState(null);
  const [savedProjects, setSavedProjects] = useState([]);
  const [showProjectsModal, setShowProjectsModal] = useState(false);

  const canvasRef = useRef(null);
  const dragStartRef = useRef(null);
  const [dragBox, setDragBox] = useState(null);

  useEffect(() => {
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);
    const handleBeforeInstall = (e) => {
      e.preventDefault();
      setDeferredPrompt(e);
    };
    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);
    window.addEventListener('beforeinstallprompt', handleBeforeInstall);
    try {
      const stored = localStorage.getItem('wilcom_pwa_projects_v2');
      if (stored) setSavedProjects(JSON.parse(stored));
    } catch {}
    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
      window.removeEventListener('beforeinstallprompt', handleBeforeInstall);
    };
  }, []);

  const pushUndoSnapshot = useCallback(() => {
    setUndoStack((prev) => [
      ...prev.slice(-8),
      {
        designMode,
        calligraphyText,
        bottomCaption,
        hasCrown,
        widthMm,
        heightMm,
        fabricBg,
        needles: JSON.parse(JSON.stringify(needles)),
        masks: {
          1: new Uint8Array(layerMasksRef.current[1]),
          2: new Uint8Array(layerMasksRef.current[2]),
          3: new Uint8Array(layerMasksRef.current[3]),
        },
      },
    ]);
  }, [designMode, calligraphyText, bottomCaption, hasCrown, widthMm, heightMm, fabricBg, needles]);

  const handleUndo = useCallback(() => {
    setUndoStack((prev) => {
      if (prev.length === 0) return prev;
      const last = prev[prev.length - 1];
      setDesignMode(last.designMode);
      setCalligraphyText(last.calligraphyText);
      setBottomCaption(last.bottomCaption);
      setHasCrown(last.hasCrown);
      setWidthMm(last.widthMm);
      setHeightMm(last.heightMm);
      setFabricBg(last.fabricBg);
      setNeedles(last.needles);
      layerMasksRef.current = {
        1: new Uint8Array(last.masks[1]),
        2: new Uint8Array(last.masks[2]),
        3: new Uint8Array(last.masks[3]),
      };
      setMaskVersion((v) => v + 1);
      setLastDiffBanner('تم التراجع خطوة للوراء (Undo)');
      return prev.slice(0, -1);
    });
  }, []);

  // بناء أقنعة المخطوطة العربية (3 ألوان)
  const buildCalligraphyMasks = useCallback((word, crownFlag, captionText, borderThicknessMm = 2.4) => {
    const off = document.createElement('canvas');
    off.width = MASK_W;
    off.height = MASK_H;
    const ctx = off.getContext('2d');
    ctx.fillStyle = '#000000';
    ctx.fillRect(0, 0, MASK_W, MASK_H);

    ctx.fillStyle = '#FFFFFF';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    const fontSize = word.length > 6 ? 78 : 108;
    ctx.font = `900 ${fontSize}px "Cairo", "Arial", sans-serif`;
    ctx.fillText(word, MASK_W / 2, MASK_H / 2 + (crownFlag ? 16 : 0));

    const imgData = ctx.getImageData(0, 0, MASK_W, MASK_H).data;
    const m1 = new Uint8Array(MASK_W * MASK_H);
    const m2 = new Uint8Array(MASK_W * MASK_H);
    const m3 = new Uint8Array(MASK_W * MASK_H);

    let minX = MASK_W, maxX = 0;
    for (let y = 0; y < MASK_H; y++) {
      for (let x = 0; x < MASK_W; x++) {
        if (imgData[(y * MASK_W + x) * 4] > 120) {
          if (x < minX) minX = x;
          if (x > maxX) maxX = x;
        }
      }
    }
    const span = Math.max(1, maxX - minX);
    const bRad = Math.max(2, Math.round(borderThicknessMm * 1.45));

    for (let y = 2; y < MASK_H - 2; y++) {
      for (let x = 2; x < MASK_W - 2; x++) {
        const idx = y * MASK_W + x;
        const inside = imgData[idx * 4] > 120;
        if (inside) {
          let isEdge = false;
          for (let dy = -bRad; dy <= bRad && !isEdge; dy += 2) {
            for (let dx = -bRad; dx <= bRad; dx += 2) {
              const nx = x + dx, ny = y + dy;
              if (nx >= 0 && nx < MASK_W && ny >= 0 && ny < MASK_H) {
                if (imgData[(ny * MASK_W + nx) * 4] <= 120) {
                  isEdge = true;
                  break;
                }
              }
            }
          }
          if (isEdge) {
            m3[idx] = 1;
          } else {
            const relX = (x - minX) / span;
            if (relX > 0.28 && relX < 0.68) m2[idx] = 1;
            else m1[idx] = 1;
          }
        }
      }
    }

    if (crownFlag) {
      const cx = MASK_W / 2, cy = 42;
      for (let y = 14; y <= 58; y++) {
        for (let x = cx - 55; x <= cx + 55; x++) {
          const dx = x - cx;
          const base = y >= 46 && y <= 55 && Math.abs(dx) <= 46;
          const peak1 = Math.abs(dx) <= 12 && y >= 18 + Math.abs(dx) * 1.5 && y <= 48;
          const peakL = Math.abs(dx + 32) <= 12 && y >= 24 + Math.abs(dx + 32) * 1.4 && y <= 48;
          const peakR = Math.abs(dx - 32) <= 12 && y >= 24 + Math.abs(dx - 32) * 1.4 && y <= 48;
          if (base || peak1 || peakL || peakR) {
            m3[Math.round(y) * MASK_W + Math.round(x)] = 1;
          }
        }
      }
    }

    if (captionText) {
      const capOff = document.createElement('canvas');
      capOff.width = MASK_W;
      capOff.height = MASK_H;
      const cctx = capOff.getContext('2d');
      cctx.fillStyle = '#FFFFFF';
      cctx.font = 'bold 34px "Cairo", sans-serif';
      cctx.textAlign = 'center';
      cctx.fillText(captionText, MASK_W / 2, MASK_H - 24);
      const capData = cctx.getImageData(0, 0, MASK_W, MASK_H).data;
      for (let i = 0; i < MASK_W * MASK_H; i++) {
        if (capData[i * 4] > 120) m3[i] = 1;
      }
    }

    layerMasksRef.current = { 1: m1, 2: m2, 3: m3 };
    setMaskVersion((v) => v + 1);
  }, []);

  // بناء قناع البورش الكلاسيكية (Classic Smoke) الجاهز
  const loadClassicSmokePreset = useCallback(() => {
    pushUndoSnapshot();
    const m1 = new Uint8Array(MASK_W * MASK_H); // Black outlines & text
    const m2 = new Uint8Array(MASK_W * MASK_H); // Grey smoke & white highlights
    const m3 = new Uint8Array(MASK_W * MASK_H); // Blue car body & text shadow

    const off = document.createElement('canvas');
    off.width = MASK_W;
    off.height = MASK_H;
    const ctx = off.getContext('2d');

    // رسم جسم البورش في الطبقة 3 (الأزرق)
    ctx.fillStyle = '#0000FF';
    ctx.beginPath();
    ctx.moveTo(45, 175);
    ctx.lineTo(85, 145);
    ctx.quadraticCurveTo(185, 92, 265, 102);
    ctx.lineTo(325, 145);
    ctx.lineTo(435, 158);
    ctx.lineTo(445, 195);
    ctx.lineTo(45, 195);
    ctx.closePath();
    ctx.fill();

    // تفريغ النوافذ
    ctx.fillStyle = '#000000';
    ctx.beginPath();
    ctx.moveTo(145, 140);
    ctx.quadraticCurveTo(205, 108, 255, 112);
    ctx.lineTo(295, 142);
    ctx.closePath();
    ctx.fill();

    const bodyData = ctx.getImageData(0, 0, MASK_W, MASK_H).data;
    for (let i = 0; i < MASK_W * MASK_H; i++) {
      if (bodyData[i * 4 + 2] > 120) m3[i] = 1;
    }

    // رسم الدخان في الطبقة 2 (رمادي/أبيض)
    ctx.clearRect(0, 0, MASK_W, MASK_H);
    ctx.strokeStyle = '#FFFFFF';
    ctx.lineWidth = 9;
    ctx.lineCap = 'round';
    ctx.beginPath();
    ctx.moveTo(235, 128);
    ctx.bezierCurveTo(285, 95, 295, 65, 240, 42);
    ctx.moveTo(120, 88);
    ctx.quadraticCurveTo(175, 72, 218, 86);
    ctx.stroke();
    const smokeData = ctx.getImageData(0, 0, MASK_W, MASK_H).data;
    for (let i = 0; i < MASK_W * MASK_H; i++) {
      if (smokeData[i * 4] > 120) m2[i] = 1;
    }

    // رسم الكاوتش والخطوط وكلمة CLASSIC SMOKE في الطبقة 1 (الأسود)
    ctx.clearRect(0, 0, MASK_W, MASK_H);
    ctx.fillStyle = '#FFFFFF';
    ctx.beginPath();
    ctx.arc(135, 195, 32, 0, Math.PI * 2);
    ctx.arc(365, 195, 32, 0, Math.PI * 2);
    ctx.fill();
    ctx.font = '900 28px "Arial Black", sans-serif';
    ctx.fillText('CLASSIC', 375, 72);
    ctx.fillText('SMOKE', 375, 104);
    const blkData = ctx.getImageData(0, 0, MASK_W, MASK_H).data;
    for (let i = 0; i < MASK_W * MASK_H; i++) {
      if (blkData[i * 4] > 120) {
        m1[i] = 1;
        m3[i] = 0;
      }
    }

    layerMasksRef.current = { 1: m1, 2: m2, 3: m3 };
    setDesignMode('bitmap');
    setNeedles([
      { id: 1, name: 'الإبرة #1 (التحديد والكتابة)', color: '#141416', code: '#1800', type: 'Satin', density: 0.36, angle: 45, pullComp: 0.25, satinWidth: 2.0, visible: true },
      { id: 2, name: 'الإبرة #2 (الدخان واللمعات)', color: '#94A3B8', code: '#1818', type: 'Tatami', density: 0.38, angle: 30, pullComp: 0.25, satinWidth: 2.2, visible: true },
      { id: 3, name: 'الإبرة #3 (جسم البورش الأزرق)', color: '#0D47A1', code: '#1842', type: 'Tatami', density: 0.36, angle: 0, pullComp: 0.30, satinWidth: 2.4, visible: true },
    ]);
    setMaskVersion((v) => v + 1);
    setLastDiffBanner('تم تحميل تصميم Classic Smoke Porsche (3 إبر)');
  }, [pushUndoSnapshot]);

  // التوليد الأولي لمخطوطة "محمد"
  useEffect(() => {
    if (designMode === 'calligraphy') {
      const n3 = needles.find((n) => n.id === 3);
      buildCalligraphyMasks(calligraphyText, hasCrown, bottomCaption, n3 ? n3.satinWidth : 2.4);
    }
  }, [designMode, calligraphyText, hasCrown, bottomCaption, buildCalligraphyMasks]);

  // تحويل الأقنعة إلى إحداثيات غرز حقيقية
  useEffect(() => {
    const newStitches = { 1: [], 2: [], 3: [] };
    let total = 0;
    let jumps = 0;

    needles.forEach((n) => {
      if (!n.visible) return;
      const mask = layerMasksRef.current[n.id];
      if (!mask) return;

      const rowStep = Math.max(2, Math.round(n.density * 7.5));
      const colStep = n.type === 'Satin' ? 6 : n.type === 'Cross' ? 7 : 9;
      const pts = [];
      let dir = 1;

      for (let y = 2; y < MASK_H - 2; y += rowStep) {
        let inSeg = false;
        let segStart = 0;
        const startX = dir === 1 ? 2 : MASK_W - 3;
        const endX = dir === 1 ? MASK_W - 2 : 1;

        for (let x = startX; dir === 1 ? x < endX : x > endX; x += dir) {
          const on = mask[y * MASK_W + x] === 1;
          if (on && !inSeg) {
            inSeg = true;
            segStart = x;
          } else if ((!on || Math.abs(x - segStart) >= colStep) && inSeg) {
            const mx1 = ((segStart - MASK_W / 2) / MASK_W) * widthMm;
            const my1 = ((y - MASK_H / 2) / MASK_H) * heightMm;
            const mx2 = ((x - MASK_W / 2) / MASK_W) * widthMm;
            const my2 = ((y + (n.type === 'Cross' ? rowStep * 0.8 : 0) - MASK_H / 2) / MASK_H) * heightMm;

            const isJump = pts.length > 0 && Math.hypot(mx1 - pts[pts.length - 1].x, my1 - pts[pts.length - 1].y) > 4.5;
            if (isJump) jumps++;

            pts.push({ x: mx1, y: my1, jump: isJump });
            pts.push({ x: mx2, y: my2, jump: false });
            if (on) segStart = x;
            else inSeg = false;
          }
        }
        dir *= -1;
      }
      newStitches[n.id] = pts;
      total += pts.length;
    });

    setStitchesByNeedle(newStitches);
    setTotalStitches(total);
    setJumpCount(jumps);
  }, [needles, maskVersion, widthMm, heightMm]);

  // رسم الغرز في الكانفاس ثلاثي الأبعاد
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    const cw = canvas.width;
    const ch = canvas.height;

    ctx.fillStyle = fabricBg;
    ctx.fillRect(0, 0, cw, ch);

    // شبكة الطارة القياسية
    ctx.strokeStyle = 'rgba(255,255,255,0.06)';
    ctx.lineWidth = 1;
    for (let x = 0; x < cw; x += 28) {
      ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, ch); ctx.stroke();
    }
    for (let y = 0; y < ch; y += 28) {
      ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(cw, y); ctx.stroke();
    }

    // محاور السنتر (0,0)
    ctx.strokeStyle = 'rgba(239,68,68,0.35)';
    ctx.setLineDash([5, 5]);
    ctx.beginPath();
    ctx.moveTo(cw / 2, 0); ctx.lineTo(cw / 2, ch);
    ctx.moveTo(0, ch / 2); ctx.lineTo(cw, ch / 2);
    ctx.stroke();
    ctx.setLineDash([]);

    // إطار الطارة
    ctx.strokeStyle = 'rgba(148,163,184,0.28)';
    ctx.lineWidth = 8;
    ctx.strokeRect(26, 20, cw - 52, ch - 40);

    const scalePx = ( (cw - 110) / widthMm ) * zoom;
    let maxStitchesToDraw = Math.floor(totalStitches * playProgress);
    let drawn = 0;

    needles.forEach((n) => {
      if (!n.visible) return;
      const pts = stitchesByNeedle[n.id] || [];
      if (pts.length === 0) return;

      ctx.save();
      ctx.strokeStyle = n.color;
      ctx.lineCap = 'round';
      ctx.lineJoin = 'round';
      ctx.lineWidth = viewMode === 'vectors' ? 1.1 : n.type === 'Satin' ? 2.6 : 2.1;

      if (viewMode === 'trueview') {
        ctx.shadowColor = 'rgba(0,0,0,0.45)';
        ctx.shadowBlur = 2;
        ctx.shadowOffsetY = 1;
      }

      ctx.beginPath();
      for (let i = 0; i < pts.length; i++) {
        if (drawn >= maxStitchesToDraw) break;
        const p = pts[i];
        const sx = cw / 2 + p.x * scalePx;
        const sy = ch / 2 + p.y * scalePx;
        if (i === 0 || p.jump) ctx.moveTo(sx, sy);
        else ctx.lineTo(sx, sy);
        drawn++;
      }
      ctx.stroke();
      ctx.restore();
    });

    if (dragBox) {
      ctx.save();
      ctx.strokeStyle = mouseTool === 'eraser' ? '#ef4444' : '#f59e0b';
      ctx.fillStyle = mouseTool === 'eraser' ? 'rgba(239,68,68,0.18)' : 'rgba(245,158,11,0.18)';
      ctx.lineWidth = 2;
      ctx.setLineDash([6, 4]);
      const rx = Math.min(dragBox.x1, dragBox.x2);
      const ry = Math.min(dragBox.y1, dragBox.y2);
      const rw = Math.abs(dragBox.x2 - dragBox.x1);
      const rh = Math.abs(dragBox.y2 - dragBox.y1);
      ctx.fillRect(rx, ry, rw, rh);
      ctx.strokeRect(rx, ry, rw, rh);
      ctx.restore();
    }
  }, [needles, stitchesByNeedle, totalStitches, playProgress, fabricBg, viewMode, zoom, widthMm, dragBox, mouseTool]);

  // تشغيل أنيميشن الماكينة
  useEffect(() => {
    if (!isPlaying) return;
    const interval = setInterval(() => {
      setPlayProgress((prev) => {
        if (prev >= 1) {
          setIsPlaying(false);
          return 1;
        }
        return Math.min(1, prev + (spm / 35000));
      });
    }, 30);
    return () => clearInterval(interval);
  }, [isPlaying, spm]);

  // رفع أي صورة وفصلها تلقائياً إلى 3 إبر
  const handleImageUpload = (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    pushUndoSnapshot();

    const reader = new FileReader();
    reader.onload = (ev) => {
      const img = new Image();
      img.onload = () => {
        const off = document.createElement('canvas');
        off.width = MASK_W;
        off.height = MASK_H;
        const ctx = off.getContext('2d');
        ctx.fillStyle = '#FFFFFF';
        ctx.fillRect(0, 0, MASK_W, MASK_H);

        const scale = Math.min((MASK_W - 30) / img.width, (MASK_H - 30) / img.height);
        const dw = img.width * scale;
        const dh = img.height * scale;
        ctx.drawImage(img, (MASK_W - dw) / 2, (MASK_H - dh) / 2, dw, dh);

        const data = ctx.getImageData(0, 0, MASK_W, MASK_H).data;
        const m1 = new Uint8Array(MASK_W * MASK_H);
        const m2 = new Uint8Array(MASK_W * MASK_H);
        const m3 = new Uint8Array(MASK_W * MASK_H);

        for (let i = 0; i < MASK_W * MASK_H; i++) {
          const r = data[i * 4], g = data[i * 4 + 1], b = data[i * 4 + 2];
          if (r > 240 && g > 240 && b > 240) continue; // تجاهل الخلفية البيضاء
          const lum = 0.299 * r + 0.587 * g + 0.114 * b;
          const maxC = Math.max(r, g, b), minC = Math.min(r, g, b);
          const sat = maxC === 0 ? 0 : (maxC - minC) / maxC;

          if (lum < 75) m1[i] = 1;
          else if (sat > 0.28) m3[i] = 1;
          else m2[i] = 1;
        }

        layerMasksRef.current = { 1: m1, 2: m2, 3: m3 };
        setDesignMode('bitmap');
        setMaskVersion((v) => v + 1);
        setLastDiffBanner(`تم فصل ألوان الصورة "${file.name}" إلى 3 إبر بنجاح`);
      };
      img.src = ev.target.result;
    };
    reader.readAsDataURL(file);
  };

  // الممحاة وتلوين المناطق بالماوس على الكانفاس
  const handleCanvasMouseDown = (e) => {
    if (mouseTool === 'pan') return;
    const rect = canvasRef.current.getBoundingClientRect();
    const x = ((e.clientX - rect.left) / rect.width) * canvasRef.current.width;
    const y = ((e.clientY - rect.top) / rect.height) * canvasRef.current.height;
    dragStartRef.current = { x, y };
    setDragBox({ x1: x, y1: y, x2: x, y2: y });
  };

  const handleCanvasMouseMove = (e) => {
    if (!dragStartRef.current) return;
    const rect = canvasRef.current.getBoundingClientRect();
    const x = ((e.clientX - rect.left) / rect.width) * canvasRef.current.width;
    const y = ((e.clientY - rect.top) / rect.height) * canvasRef.current.height;
    setDragBox({ x1: dragStartRef.current.x, y1: dragStartRef.current.y, x2: x, y2: y });
  };

  const handleCanvasMouseUp = () => {
    if (!dragBox || !canvasRef.current) return;
    pushUndoSnapshot();
    const cw = canvasRef.current.width;
    const ch = canvasRef.current.height;
    const xMin = Math.floor((Math.min(dragBox.x1, dragBox.x2) / cw) * MASK_W);
    const xMax = Math.ceil((Math.max(dragBox.x1, dragBox.x2) / cw) * MASK_W);
    const yMin = Math.floor((Math.min(dragBox.y1, dragBox.y2) / ch) * MASK_H);
    const yMax = Math.ceil((Math.max(dragBox.y1, dragBox.y2) / ch) * MASK_H);

    for (let y = Math.max(0, yMin); y < Math.min(MASK_H, yMax); y++) {
      for (let x = Math.max(0, xMin); x < Math.min(MASK_W, xMax); x++) {
        const idx = y * MASK_W + x;
        if (mouseTool === 'eraser') {
          layerMasksRef.current[1][idx] = 0;
          layerMasksRef.current[2][idx] = 0;
          layerMasksRef.current[3][idx] = 0;
        } else if (mouseTool === 'recolor') {
          const hadAny =
            layerMasksRef.current[1][idx] ||
            layerMasksRef.current[2][idx] ||
            layerMasksRef.current[3][idx];
          if (hadAny) {
            layerMasksRef.current[1][idx] = targetRecolorNeedle === 1 ? 1 : 0;
            layerMasksRef.current[2][idx] = targetRecolorNeedle === 2 ? 1 : 0;
            layerMasksRef.current[3][idx] = targetRecolorNeedle === 3 ? 1 : 0;
          }
        }
      }
    }

    dragStartRef.current = null;
    setDragBox(null);
    setMaskVersion((v) => v + 1);
    setLastDiffBanner(mouseTool === 'eraser' ? 'تم مسح المنطقة المحددة من الأفلام' : `تم نقل المنطقة المحددة إلى الإبرة #${targetRecolorNeedle}`);
  };

  // محرك الذكاء الاصطناعي باللغة الطبيعية (العامية المصرية والفصحى)
  const executeNaturalLanguageCommand = (rawCmd) => {
    const cmd = rawCmd.trim();
    if (!cmd) return;
    pushUndoSnapshot();
    const diffs = [];
    let updatedNeedles = JSON.parse(JSON.stringify(needles));

    // 1. فحص أوامر الحذف والمسح المكاني أولاً (قبل أي أمر كتابة!)
    const isDeleteCmd = /(احذف|إحذف|امسح|إمسح|شيل|الغي|إلغاء|بدون|شطب)/.test(cmd);
    if (isDeleteCmd) {
      if (/(الانجليزي|الإنجليزي|الكلمه|الكلمة|الكتابه|الكتابة|النص|الحروف|classic|smoke)/i.test(cmd)) {
        for (let y = 0; y < Math.floor(MASK_H * 0.56); y++) {
          for (let x = Math.floor(MASK_W * 0.58); x < MASK_W; x++) {
            const idx = y * MASK_W + x;
            layerMasksRef.current[1][idx] = 0;
            layerMasksRef.current[2][idx] = 0;
            layerMasksRef.current[3][idx] = 0;
          }
        }
        setBottomCaption('');
        setMaskVersion((v) => v + 1);
        diffs.push('تم مسح الكلمة الإنجليزية (CLASSIC SMOKE) من التصميم مع الحفاظ على الرسمة');
      }
      if (/(الدخان|دخان|الرمادي|السحاب)/.test(cmd)) {
        layerMasksRef.current[2].fill(0);
        setMaskVersion((v) => v + 1);
        diffs.push('تم مسح طبقة الدخان بالكامل');
      }
      if (/(تاج|التاج)/.test(cmd)) {
        setHasCrown(false);
        diffs.push('تم حذف التاج العلوي');
      }
      if (/(البرواز|الإطار|الاطار|التحديد)/.test(cmd)) {
        updatedNeedles = updatedNeedles.map((n) => (n.id === 3 ? { ...n, visible: false } : n));
        diffs.push('تم إخفاء إبرة البرواز الخارجي');
      }
    } else {
      // 2. أوامر كتابة أو تغيير النص
      const writeMatch = cmd.match(/(?:اكتب|أكتب|غير الاسم ل|خلي الكلمه|خلي الكلمة|مخطوطة|اسم)\s+([^\s،,.]+(?:\s+[^\s،,.]+)?)/);
      if (writeMatch) {
        const cleanWord = writeMatch[1].replace(/^(كلمه|كلمة|اسم)\s+/, '').trim();
        if (cleanWord && !['الانجليزية', 'الكتابة', 'الدخان'].includes(cleanWord)) {
          if (designMode === 'bitmap') {
            setBottomCaption(cleanWord);
            const capOff = document.createElement('canvas');
            capOff.width = MASK_W; capOff.height = MASK_H;
            const cctx = capOff.getContext('2d');
            cctx.fillStyle = '#FFFFFF';
            cctx.font = 'bold 34px "Cairo", sans-serif';
            cctx.textAlign = 'center';
            cctx.fillText(cleanWord, MASK_W / 2, MASK_H - 18);
            const capData = cctx.getImageData(0, 0, MASK_W, MASK_H).data;
            for (let i = 0; i < MASK_W * MASK_H; i++) {
              if (capData[i * 4] > 120) layerMasksRef.current[1][i] = 1;
            }
            setMaskVersion((v) => v + 1);
            diffs.push(`تمت إضافة مخطوطة "${cleanWord}" أسفل التصميم`);
          } else {
            setCalligraphyText(cleanWord);
            diffs.push(`تغيير المخطوطة إلى: "${cleanWord}"`);
          }
        }
      }
    }

    // 3. إضافة تاج
    if (!isDeleteCmd && /(تاج|ملك|ملكي)/.test(cmd)) {
      setHasCrown(true);
      diffs.push('إضافة تاج ملكي مطرز أعلى التصميم');
    }

    // 4. تغيير الألوان (البرواز، القلب، العربية، الإبر)
    MADEIRA_PALETTE.forEach((pal) => {
      if (pal.keywords.some((kw) => cmd.toLowerCase().includes(kw))) {
        if (/(برواز|إطار|اطار|تحديد|ابره 3|إبرة 3|العربيه|العربية|جسم)/.test(cmd)) {
          updatedNeedles = updatedNeedles.map((n) => (n.id === 3 ? { ...n, color: pal.hex, code: pal.code } : n));
          diffs.push(`لون الإبرة #3 ← ${pal.name} (${pal.code})`);
        } else if (/(قلب|منتصف|وسط|نص|ابره 2|إبرة 2|الدخان)/.test(cmd)) {
          updatedNeedles = updatedNeedles.map((n) => (n.id === 2 ? { ...n, color: pal.hex, code: pal.code } : n));
          diffs.push(`لون الإبرة #2 ← ${pal.name} (${pal.code})`);
        } else if (/(ابره 1|إبرة 1|أطراف|اطراف|يمين)/.test(cmd)) {
          updatedNeedles = updatedNeedles.map((n) => (n.id === 1 ? { ...n, color: pal.hex, code: pal.code } : n));
          diffs.push(`لون الإبرة #1 ← ${pal.name} (${pal.code})`);
        }
      }
    });

    // 5. تخانة البرواز والكثافة والزاوية ونوع الغرزة
    if (/(عريض|تخين|سميك|كبر البرواز)/.test(cmd)) {
      updatedNeedles = updatedNeedles.map((n) => (n.id === 3 ? { ...n, satinWidth: 3.4 } : n));
      diffs.push('تخانة برواز الساتان ← 3.4 مم (عريض)');
    }
    const densMatch = cmd.match(/(0\.\d+)/);
    if (densMatch || /(زود الكثافه|زود الكثافة|كثف)/.test(cmd)) {
      const newD = densMatch ? parseFloat(densMatch[1]) : 0.28;
      updatedNeedles = updatedNeedles.map((n) => ({ ...n, density: Math.max(0.22, Math.min(0.6, newD)) }));
      diffs.push(`كثافة الغرز ← ${newD} مم`);
    }
    if (/(كروس|ايتامين|إيتامين|cross)/i.test(cmd)) {
      updatedNeedles = updatedNeedles.map((n) => (n.id !== 3 ? { ...n, type: 'Cross' } : n));
      diffs.push('تحويل الغرز إلى كروس إيتامين (Cross Stitch)');
    }

    if (diffs.length === 0) {
      diffs.push('تم تحديث معلمات الغرز وإعادة حساب المسارات');
    }

    setNeedles(updatedNeedles);
    setLastDiffBanner(diffs.join(' | '));
    setChatHistory((prev) => [...prev, { role: 'user', text: cmd }, { role: 'ai', text: 'تم تنفيذ التعديل فوراً على الرسمة في المحاكي:', diffs }]);
    setChatInput('');
  };

  // حفظ مباشر على الفلاشة بصيغة .DST
  const handleDirectSaveDST = async () => {
    const blob = generateBinaryDST(calligraphyText || 'WILCOM_AI', needles, stitchesByNeedle);
    const fileName = `${calligraphyText || 'Design'}_WilcomAI_${widthMm}mm.dst`;
    if ('showSaveFilePicker' in window) {
      try {
        const handle = await window.showSaveFilePicker({
          suggestedName: fileName,
          types: [{ description: 'Tajima Embroidery DST', accept: { 'application/octet-stream': ['.dst'] } }],
        });
        const writable = await handle.createWritable();
        await writable.write(blob);
        await writable.close();
        setLastDiffBanner(`تم حفظ ${fileName} مباشرة على الفلاشة / الجهاز!`);
        return;
      } catch {}
    }
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = fileName;
    a.click();
    URL.revokeObjectURL(url);
  };

  // حفظ المشروع في مكتبة المتصفح Offline
  const saveCurrentProjectOffline = () => {
    const proj = {
      id: Date.now(),
      title: designMode === 'calligraphy' ? `مخطوطة: ${calligraphyText}` : 'تصميم مفرز بالذكاء الاصطناعي',
      date: new Date().toLocaleTimeString('ar-EG'),
      totalStitches,
      designMode,
      calligraphyText,
      widthMm,
      heightMm,
      needles,
    };
    const next = [proj, ...savedProjects.slice(0, 9)];
    setSavedProjects(next);
    try {
      localStorage.setItem('wilcom_pwa_projects_v2', JSON.stringify(next));
    } catch {}
    setLastDiffBanner('تم حفظ المشروع في المكتبة المحلية (Offline Storage)');
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col">
      {/* الشريط العلوي لتطبيق الـ PWA */}
      <header className="bg-slate-900/95 border-b border-slate-800 px-4 py-2.5 flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-amber-500/20 border border-amber-500/40 flex items-center justify-center text-amber-400 font-black text-xl">
            W
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="font-extrabold text-base text-white">Wilcom AI Studio Pro</h1>
              <span className="text-[11px] px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 font-semibold">
                PWA v2.0
              </span>
              <span className={`text-[11px] px-2 py-0.5 rounded-full flex items-center gap-1 ${isOnline ? 'bg-sky-500/15 text-sky-300' : 'bg-amber-500/20 text-amber-300'}`}>
                {isOnline ? <Wifi className="w-3 h-3" /> : <WifiOff className="w-3 h-3" />}
                {isOnline ? 'متصل' : 'وضع أوفلاين'}
              </span>
            </div>
            <p className="text-xs text-slate-400">محرك ويلكم الذكي لفرز وتعديل أفلام التطريز بالأوامر الطبيعية</p>
          </div>
        </div>

        {/* أدوات التحكم السريعة */}
        <div className="flex flex-wrap items-center gap-2">
          {deferredPrompt && (
            <button
              onClick={() => deferredPrompt.prompt()}
              className="px-3 py-1.5 rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs flex items-center gap-1.5 shadow-lg"
            >
              <Smartphone className="w-4 h-4" />
              تثبيت التطبيق (Install App)
            </button>
          )}

          <button
            onClick={() => setDesignMode('calligraphy')}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold border transition ${designMode === 'calligraphy' ? 'bg-amber-500/20 border-amber-500 text-amber-300' : 'bg-slate-800 border-slate-700 text-slate-300'}`}
          >
            مخطوطة محمد (3 ألوان)
          </button>

          <button
            onClick={loadClassicSmokePreset}
            className="px-3 py-1.5 rounded-lg text-xs font-bold bg-blue-600/20 border border-blue-500/40 text-blue-300 hover:bg-blue-600/30"
          >
            بورش Classic Smoke
          </button>

          <label className="px-3 py-1.5 rounded-lg text-xs font-bold bg-emerald-600/20 border border-emerald-500/40 text-emerald-300 hover:bg-emerald-600/30 cursor-pointer flex items-center gap-1.5">
            <Upload className="w-3.5 h-3.5" />
            رفع صورة / لوجو للفصل
            <input type="file" accept="image/*" onChange={handleImageUpload} className="hidden" />
          </label>

          <button
            onClick={handleDirectSaveDST}
            className="px-3.5 py-1.5 rounded-lg text-xs font-extrabold bg-emerald-500 hover:bg-emerald-400 text-slate-950 flex items-center gap-1.5 shadow"
          >
            <HardDrive className="w-3.5 h-3.5" />
            حفظ للفلاشة (.DST)
          </button>

          <button
            onClick={saveCurrentProjectOffline}
            className="px-2.5 py-1.5 rounded-lg text-xs font-semibold bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-200 flex items-center gap-1"
          >
            <Save className="w-3.5 h-3.5 text-amber-400" />
            حفظ
          </button>

          <button
            onClick={() => setShowProjectsModal(true)}
            className="px-2.5 py-1.5 rounded-lg text-xs font-semibold bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-200 flex items-center gap-1"
          >
            <FolderOpen className="w-3.5 h-3.5 text-sky-400" />
            مشاريعي ({savedProjects.length})
          </button>

          <button
            onClick={handleUndo}
            disabled={undoStack.length === 0}
            className="px-2.5 py-1.5 rounded-lg text-xs font-semibold bg-slate-800 border border-slate-700 disabled:opacity-40 flex items-center gap-1"
          >
            <Undo2 className="w-3.5 h-3.5" />
            تراجع
          </button>
        </div>
      </header>

      {/* المحتوى الرئيسي */}
      <div className="flex-1 grid grid-cols-1 lg:grid-cols-12 gap-4 p-4">
        {/* العمود الأيمن: إدارة الإبر والأفلام */}
        <div className="lg:col-span-3 space-y-3">
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-3.5 space-y-3">
            <h2 className="font-bold text-sm text-amber-400 flex items-center justify-between">
              <span className="flex items-center gap-1.5">
                <Layers className="w-4 h-4" />
                إبر الماكينة والأفلام (3 Needles)
              </span>
            </h2>

            {needles.map((n) => (
              <div key={n.id} className="p-3 rounded-lg bg-slate-950/90 border border-slate-800 space-y-2">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <input
                      type="color"
                      value={n.color}
                      onChange={(e) => {
                        pushUndoSnapshot();
                        setNeedles((prev) => prev.map((item) => (item.id === n.id ? { ...item, color: e.target.value } : item)));
                      }}
                      className="w-6 h-6 rounded cursor-pointer border-0 bg-transparent"
                    />
                    <div>
                      <div className="text-xs font-bold text-white">{n.name}</div>
                      <div className="text-[10px] text-slate-400">
                        Madeira {n.code} | {(stitchesByNeedle[n.id]?.length || 0).toLocaleString()} غرزة
                      </div>
                    </div>
                  </div>
                  <button
                    onClick={() => setNeedles((prev) => prev.map((item) => (item.id === n.id ? { ...item, visible: !item.visible } : item)))}
                    className="p-1.5 rounded bg-slate-800 text-slate-300 hover:text-white"
                  >
                    {n.visible ? <Eye className="w-3.5 h-3.5 text-emerald-400" /> : <EyeOff className="w-3.5 h-3.5 text-slate-500" />}
                  </button>
                </div>

                <div className="grid grid-cols-2 gap-2 text-[11px]">
                  <div>
                    <label className="text-slate-400 block mb-0.5">نوع الغرزة</label>
                    <select
                      value={n.type}
                      onChange={(e) => setNeedles((prev) => prev.map((item) => (item.id === n.id ? { ...item, type: e.target.value } : item)))}
                      className="w-full bg-slate-900 border border-slate-700 rounded px-2 py-1 text-white"
                    >
                      <option value="Tatami">Tatami (تاتامي)</option>
                      <option value="Satin">Satin (ساتان بارز)</option>
                      <option value="Cross">Cross (إيتامين)</option>
                    </select>
                  </div>
                  <div>
                    <label className="text-slate-400 block mb-0.5">الكثافة: {n.density} مم</label>
                    <input
                      type="range"
                      min="0.24"
                      max="0.55"
                      step="0.02"
                      value={n.density}
                      onChange={(e) => setNeedles((prev) => prev.map((item) => (item.id === n.id ? { ...item, density: parseFloat(e.target.value) } : item)))}
                      className="w-full accent-amber-500"
                    />
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* العمود الأوسط: محاكي الغرز TrueView 3D */}
        <div className="lg:col-span-6 flex flex-col gap-3">
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-3 flex flex-wrap items-center justify-between gap-2">
            <div className="flex items-center gap-2 text-xs">
              <span className="px-2 py-0.5 rounded bg-amber-500/20 text-amber-300 font-bold">آخر تعديل حي:</span>
              <span className="text-emerald-300 font-semibold">{lastDiffBanner}</span>
            </div>
            <div className="flex items-center gap-1.5">
              <button
                onClick={() => setMouseTool(mouseTool === 'eraser' ? 'pan' : 'eraser')}
                className={`px-2.5 py-1 rounded text-xs font-bold flex items-center gap-1 border ${mouseTool === 'eraser' ? 'bg-red-500/25 border-red-500 text-red-300' : 'bg-slate-800 border-slate-700 text-slate-300'}`}
              >
                <Eraser className="w-3.5 h-3.5" />
                ممحاة منطقة بالماوس
              </button>
              <button
                onClick={() => setMouseTool(mouseTool === 'recolor' ? 'pan' : 'recolor')}
                className={`px-2.5 py-1 rounded text-xs font-bold flex items-center gap-1 border ${mouseTool === 'recolor' ? 'bg-amber-500/25 border-amber-500 text-amber-300' : 'bg-slate-800 border-slate-700 text-slate-300'}`}
              >
                <Paintbrush className="w-3.5 h-3.5" />
                تلوين منطقة
              </button>
            </div>
          </div>

          <div className="relative bg-slate-900 border border-slate-800 rounded-xl overflow-hidden flex items-center justify-center p-2">
            <canvas
              ref={canvasRef}
              width={720}
              height={400}
              onMouseDown={handleCanvasMouseDown}
              onMouseMove={handleCanvasMouseMove}
              onMouseUp={handleCanvasMouseUp}
              className={`w-full h-auto rounded-lg ${mouseTool !== 'pan' ? 'cursor-crosshair' : 'cursor-grab'}`}
            />
          </div>

          {/* شريط تشغيل محاكي الماكينة */}
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-3 flex items-center justify-between gap-4">
            <button
              onClick={() => {
                if (playProgress >= 1) setPlayProgress(0);
                setIsPlaying(!isPlaying);
              }}
              className="px-4 py-2 rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 font-extrabold text-xs flex items-center gap-1.5"
            >
              {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
              {isPlaying ? 'إيقاف مؤقت' : 'محاكاة الماكينة غرزة بغرزة'}
            </button>
            <input
              type="range"
              min="0"
              max="1"
              step="0.01"
              value={playProgress}
              onChange={(e) => setPlayProgress(parseFloat(e.target.value))}
              className="flex-1 accent-amber-500"
            />
            <div className="text-xs font-mono text-amber-400">
              {Math.floor(totalStitches * playProgress).toLocaleString()} / {totalStitches.toLocaleString()} ST
            </div>
          </div>
        </div>

        {/* العمود الأيسر: شات التعديل الذكي باللغة الطبيعية */}
        <div className="lg:col-span-3 bg-slate-900 border border-slate-800 rounded-xl p-3.5 flex flex-col h-[580px]">
          <div className="flex items-center justify-between pb-2.5 mb-2.5 border-b border-slate-800">
            <div className="flex items-center gap-1.5 font-bold text-sm text-amber-400">
              <Sparkles className="w-4 h-4" />
              شات التعديل الحي (AI Live Chat)
            </div>
            <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300">متصل بالمحاكي 100%</span>
          </div>

          <div className="flex flex-wrap gap-1.5 mb-3">
            {[
              'احذف الكلمة الانجليزية',
              'خلي البرواز دهبي عريض والقلب بالأزرق',
              'اكتب كلمة الملك وضيف تاج',
              'زود الكثافة لـ 0.28 مم',
              'امسح الدخان',
            ].map((preset) => (
              <button
                key={preset}
                onClick={() => executeNaturalLanguageCommand(preset)}
                className="text-[11px] px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 transition"
              >
                🪄 {preset}
              </button>
            ))}
          </div>

          <div className="flex-1 overflow-y-auto space-y-2.5 pr-1">
            {chatHistory.map((msg, i) => (
              <div
                key={i}
                className={`p-2.5 rounded-lg text-xs ${msg.role === 'user' ? 'bg-amber-500/15 border border-amber-500/30 text-amber-200' : 'bg-slate-950 border border-slate-800 text-slate-300'}`}
              >
                <div className="font-bold mb-1">{msg.role === 'user' ? '👤 أمرك:' : '🤖 محرك Wilcom التفاعلي:'}</div>
                <div>{msg.text}</div>
                {msg.diffs && (
                  <div className="mt-1.5 space-y-1">
                    {msg.diffs.map((d, idx) => (
                      <div key={idx} className="text-[11px] px-2 py-1 rounded bg-emerald-500/15 text-emerald-300 border border-emerald-500/30">
                        ✓ {d}
                      </div>
                    ))}
                  </div>
                )}
              </div>
            ))}
          </div>

          <form
            onSubmit={(e) => {
              e.preventDefault();
              executeNaturalLanguageCommand(chatInput);
            }}
            className="mt-3 space-y-2"
          >
            <input
              type="text"
              value={chatInput}
              onChange={(e) => setChatInput(e.target.value)}
              placeholder="اكتب أي تعديل.. مثال: احذف الكلمة الانجليزية أو خلي البرواز دهبي"
              className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-xs text-white focus:border-amber-500 outline-none"
            />
            <button
              type="submit"
              className="w-full py-2 rounded-lg bg-gradient-to-r from-amber-500 to-orange-600 hover:from-amber-400 hover:to-orange-500 text-slate-950 font-extrabold text-xs shadow"
            >
              تنفيذ التعديل فوراً على التصميم
            </button>
          </form>
        </div>
      </div>

      {/* نافذة المشاريع المحفوظة Offline */}
      {showProjectsModal && (
        <div className="fixed inset-0 bg-black/75 flex items-center justify-center p-4 z-50">
          <div className="bg-slate-900 border border-slate-700 rounded-2xl max-w-md w-full p-4 space-y-3">
            <div className="flex items-center justify-between border-b border-slate-800 pb-2">
              <h3 className="font-bold text-sm text-amber-400">مكتبة المشاريع المحفوظة (Offline)</h3>
              <button onClick={() => setShowProjectsModal(false)} className="text-xs text-slate-400 hover:text-white">إغلاق ✕</button>
            </div>
            {savedProjects.length === 0 ? (
              <p className="text-xs text-slate-400 py-6 text-center">لا توجد مشاريع محفوظة بعد. اضغط زر "حفظ" في الشريط العلوي.</p>
            ) : (
              <div className="space-y-2 max-h-72 overflow-y-auto">
                {savedProjects.map((p) => (
                  <div key={p.id} className="p-2.5 rounded-lg bg-slate-950 border border-slate-800 flex items-center justify-between">
                    <div>
                      <div className="text-xs font-bold text-white">{p.title}</div>
                      <div className="text-[10px] text-slate-400">{p.date} — {p.totalStitches} غرزة</div>
                    </div>
                    <button
                      onClick={() => {
                        setDesignMode(p.designMode);
                        setCalligraphyText(p.calligraphyText);
                        setNeedles(p.needles);
                        setShowProjectsModal(false);
                      }}
                      className="px-2.5 py-1 rounded bg-amber-500 text-slate-950 font-bold text-xs"
                    >
                      فتح
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}